Please visit [Elegant - a theme for Pelican](http://oncrashreboot.com/pelican-elegant) at my blog for detailed features and documentation.

Elegant offers several unique features including search, live filter, collapsible comments, Mailchimp, custom 404 page, etc. It is a minimal, and stylish theme that looks amazing across all screen resolutions and devices.  

Here is an example search result

![Search result screenshot](https://raw.github.com/talha131/pelican-elegant/master/search-result-screenshot.png)

Here is how the home page looks like

![Home page screenshot](https://raw.github.com/talha131/pelican-elegant/master/home-page-screenshot.png)

This is how a generated article looks like

![Article screenshot](https://raw.github.com/talha131/pelican-elegant/master/article-screenshot.png)

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/c71132a529c1c5d7eb8dc5ea4825a851 "githalytics.com")](http://githalytics.com/talha131/pelican-elegant)

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/talha131/pelican-elegant/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
