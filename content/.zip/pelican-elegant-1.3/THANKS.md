Thanks to
=========

[tshepang](https://github.com/tshepang)
---------------------------------------

### Oct 4, 2013

1. He [reported](https://github.com/talha131/pelican-elegant/issues/10) an issue with CSS style of links in an unordered lists.

### Oct 1, 2013

1. He [reported](https://github.com/talha131/pelican-elegant/issues/6) that it is not possible to link to a Disqus comment.

### Sep 29, 2013

1. He [reported](https://github.com/talha131/pelican-elegant/issues/5) hyperlink style compatibility issue on Chrome.
1. He [reported](https://github.com/talha131/pelican-elegant/issues/3) an issue with link style.
1. He [reported](https://github.com/talha131/pelican-elegant/issues/4) the bug that Disqus comment count is always zero.

[yuex](https://github.com/yuex)
-------------------------------

### Sep 15, 2013

1. He submitted a [patch](https://github.com/talha131/pelican-elegant/pull/2) to the project.

[Melissa](https://github.com/meli-lewis)
----------------------------------------
### Sep 3, 2013

1. She reported a [critical bug](https://github.com/talha131/pelican-elegant/issues/1).

[John](http://twitter.com/BostonEnginerd)
-----------------------------------------

### Sep 2, 2013

1. He suggested [an improvement](https://twitter.com/BostonEnginerd/status/374555593589002241) to the [Elegant project description](http://oncrashreboot.com/elegant-a-clean-theme-for-pelican-with-search-feature).

[if1live](https://github.com/if1live)
-------------------------------------

### Aug 31, 2013

1. His [pull request](https://github.com/getpelican/pelican-plugins/pull/68) reminded me that I have forgotten to add template for Pages
1. His [commit](https://github.com/if1live/pelican-elegant/commit/3da52903e94051fa771212149a10a271adc78264#commitcomment-3988674) in the fork brought bug in the path of search.html to my notice

[Jérémie Astori](https://github.com/astorije)
---------------------------------------------

### Aug 30, 2013

1. He reported a [bug](https://botbot.me/freenode/pelican/msg/5577967/) in search form.
