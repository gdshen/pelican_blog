The license requires that you give credit to me, Talha Mansoor, as the author of the Elegant theme on every site that uses this theme. I have placed the attribution in the footer of every page. Do not remove it. If you need to remove or change the style of the attribution, please get in [touch with me](http://oncrashreboot.com/#about-me) first. 

Along with this attribution clause, Elegant theme is licensed under The MIT License.

If you use my theme, I would love to hear from you. [Get in touch](http://oncrashreboot.com/#about-me) and let me know about it. I may link to your site too.

Please visit License section of [Elegant - a theme for Pelican](http://oncrashreboot.com/pelican-elegant) at my blog for updated licensing details.
